/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxypattern;

import edu.db.ProxyServer;

/**
 *
 * @author lamiaa
 */
public class ProxyPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ProxyServer ps = new ProxyServer();
        System.out.println(ps.makeCaption("Open window directly"));
        System.out.println(ps.makeCaption("error in reading file"));
         System.out.println(ps.makeCaption("success"));
          System.out.println(ps.makeCaption("inser Cd"));

    }
    
}
