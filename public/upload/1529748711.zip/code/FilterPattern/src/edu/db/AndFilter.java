/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db;

import java.util.List;

/**
 *
 * @author lamiaa
 */
public class AndFilter implements Filter{
    
    private Filter criteriA , criteriaB;

    public AndFilter(Filter criteriA , Filter criteriB) {
        this.criteriA=criteriA;
        this.criteriaB = criteriB;
    }

    @Override
    public List<Trainee> match(List<Trainee> data) {
    
        return criteriaB.match(criteriA.match(data));
    }

   
    
    
    
}
