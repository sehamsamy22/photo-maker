/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lamiaa
 */
public class GenderFilter implements Filter{
    
   private boolean gender;
    public GenderFilter(boolean gender){
        this.gender = gender;
    }

    @Override
    public List<Trainee> match(List<Trainee> data) {
        List<Trainee> resul = new ArrayList<>();
        for(Trainee enTrainee :data){
            if(enTrainee.isGender() == gender){
                resul.add(enTrainee);
            }
            
        }
        return resul;
    }
    
    
    
}
