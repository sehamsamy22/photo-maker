/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db;

/**
 *
 * @author lamiaa
 */
public class Trainee {

    private String name;
    private int id;
    private String dept;
    private boolean gender;

    public Trainee(String name, int id, String dept, boolean gender) {
        this.name = name;
        this.id = id;
        this.dept = dept;
        this.gender = gender;

    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the dept
     */
    public String getDept() {
        return dept;
    }

    /**
     * @param dept the dept to set
     */
    public void setDept(String dept) {
        this.dept = dept;
    }

    /**
     * @return the gender
     */
    public boolean isGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(boolean gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return getId() + " is " + (isGender() ? " mr: " : " mis ") + getName() + " in " + getDept();
 
    }
    

}
