/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db;

import com.sun.xml.internal.ws.api.ha.StickyFeature;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lamiaa
 */
public class NameFilter implements Filter{
    
    
public NameFilter(String criteria){
    this.criteria = criteria;
}

   
    
    @Override
    public List<Trainee> match(List<Trainee> data) {
        List<Trainee> resul = new ArrayList<>();
        for(Trainee enTrainee :data){
            if(enTrainee.getName().contains((criteria)) || enTrainee.getName().equalsIgnoreCase((criteria))){
                resul.add(enTrainee);
            }
            
        }
        return resul;
    }
    
    private String criteria;
    
}
