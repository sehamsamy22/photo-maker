/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterpattern;

import edu.db.AndFilter;
import edu.db.GenderFilter;
import edu.db.NameFilter;
import edu.db.Trainee;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author lamiaa
 */
public class FilterPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here44
        Trainee tr = new Trainee("engy",1,"os",true);
        ArrayList<Trainee> ds = new ArrayList<>();
        ds.add(new Trainee("esraa",1,"os",false));
        ds.add(new Trainee("engy",2,"os",false));
        ds.add(new Trainee("mahmoud",3,"engineer",true));
        ds.add(new Trainee("ahmed",4,"sd",true));
        ds.add(new Trainee("lamiaa",5,"os",false));
        
        NameFilter criteria1 = new NameFilter("engy");
        NameFilter criteria2 = new NameFilter("esraa");
        System.out.println("Filter By Name");
        ArrayList<Trainee> out = (ArrayList<Trainee>) criteria1.match(ds);
        ArrayList<Trainee> outt = (ArrayList<Trainee>) criteria2.match(ds);
        System.out.println(Arrays.toString(out.toArray()));
        System.out.println(Arrays.toString(outt.toArray()));
         
         
         System.out.println("Filter By Gender");
         GenderFilter criteria3 = new GenderFilter(true);
         ArrayList<Trainee> outtt = (ArrayList<Trainee>) criteria3.match(ds);
         System.out.println(Arrays.toString(outtt.toArray()));
         
         
        
System.out.println("Result :" + Arrays.toString(new AndFilter(criteria2,criteria3).match(ds).toArray()));

    }
    
}
